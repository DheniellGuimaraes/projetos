<?php
function getUserName(string $userId): string {
    // Em ambiente real, buscar o nome do usuario em banco de dados
    return 'Patrícia';
}
?>
