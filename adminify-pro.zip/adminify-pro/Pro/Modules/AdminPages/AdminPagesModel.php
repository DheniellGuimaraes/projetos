<?php

namespace WPAdminify\Pro;

use WPAdminify\Inc\Base_Model;

abstract class AdminPagesModel extends Base_Model {
	protected $prefix = '_wp_adminify_';
}
