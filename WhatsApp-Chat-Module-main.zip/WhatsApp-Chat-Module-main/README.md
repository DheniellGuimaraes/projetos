# WhatsApp-Chat-Module
WhatsApp Chat Module for Perfex CRM is a Module that allows you to integrate the WhatsApp Contact button onto your Customers Area > Administration area of Perfex CRM.
1. Go to your Perfex CRM's Admin area and select the following menu item: SETUP > MODULES.
2. Upload and install it in the Perfex CRM's Modules installation section.
3. Activate the module after the successfully installation and you're done.
 
![Screenshot2](https://user-images.githubusercontent.com/83116688/155508252-668f3446-6906-487a-bdc5-8430c45ee0fc.png)
