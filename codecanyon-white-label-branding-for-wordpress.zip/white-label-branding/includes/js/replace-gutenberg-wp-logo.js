;;

( function($) {
	"use strict";
	function _replace_gutenberg_wp_logo(){
		if( 0 == $('.edit-post-header > a.components-button > svg').length ){
			setTimeout(function(){_replace_gutenberg_wp_logo();},50);
		} else {
			var _logo;
			_logo = $('<img />')
				.addClass('wlb-custom-gutenber-wp-logo')
				.attr('src', WLB_GUTENBERG_LOGO.url )
				.attr('height', '100%')
			;
			$('.edit-post-header > a.components-button')
				.css('padding',0)
			;

			$('.edit-post-header > a.components-button > svg') .replaceWith( _logo );
		}
	}

	$( document ).ready(function() {
		_replace_gutenberg_wp_logo();
	});

})(jQuery);